<?php
#adding Header
include("includes\header.php");

?>
    <!-- Page Content -->
    <div class="container">

         <div class="row">
            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    All Posts By
                    <small><?php
                            #tavasote url name nevisandaro migirim va ba ye query post hayi k name nevisandash yekie aro estekhraj mikonim
                             if (isset($_GET['author'])) {

                                $author_name=$_GET['author'];
                    echo $author_name;   ?></small>
                </h1>
                <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
                in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
                <!--  Blog Post -->
                <?php 
           
                    


                   

                    #query bara farakhani post ha 
                    $query="SELECT * FROM posts where post_author='{$author_name}' and post_status='Publish'";
                    #functione query baraye ejraye query neveshte shude be samte data base
                    $result_post_fetch=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                   while($row=mysqli_fetch_assoc($result_post_fetch)){
                       #tak take soton haye database ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                 $post_title=$row['post_title'];
                    $post_content=$row['post_content'];
                    $post_date=$row["post_date"];
                    $post_author=$row["post_author"];
                    $post_image=$row['post_image'];
                    $post_id=$row['post_id'];

                    #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                    ?>
                    <h2> <a href='post.php?p_id=<?php echo $post_id; ?>'><?php echo $post_title; ?></a></h2>  
                   
                   <p><span class='glyphicon glyphicon-time'></span> Posted on <?php echo $post_date; ?></p><hr>
                   <a href='post.php?p_id=<?php echo $post_id; ?>'> <img class='img-responsive' src='admin/images/<?php echo $post_image; ?>' alt='<?php echo $post_image; ?>'></a><hr>
                    <p><?php echo $post_content; ?></p>
                   



                    <?php
                   }
                }
                ?>
               
               
        
                
                
               
              


                



                <hr>


          
         















  </div>
  <?php include "includes/sidebar.php";
     
     #adding sidebar ?>

                </div>
             
         </div>
           
           

   

            <hr> 
        
        
        
     <?php #adding Footer
     include("includes/footer.php");
     ?>