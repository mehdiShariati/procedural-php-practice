<?php
#adding Header
include("includes\header.php");

?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>
                <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
                in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
                <!--  Blog Post -->
                <?php 
                    if (isset($_GET['c_id'])) {
                        $cat_id_from_url=$_GET['c_id'];
                    




                    #query bara farakhani post ha a tariqe PHP prepare STATEMENT

                        $stmt1=mysqli_prepare($connection,"SELECT post_id,post_title,post_author,post_content,post_date,post_image FROM posts where post_category_id = ? and post_status= ? ");
                        $publish="Publish";
                        if($stmt1 == false) {
                            die("<pre>".mysqli_error($connection)."</pre>");
                        }


                            mysqli_stmt_bind_param($stmt1,"is",$cat_id_from_url,$publish);
                            mysqli_stmt_execute($stmt1);
                            mysqli_stmt_bind_result($stmt1,$post_id,$post_title,$post_author,$post_content,$post_date,$post_image);



                    ?>











                    <?php
                //    #functione query baraye ejraye query neveshte shude be samte data base
               //     $result_post_fetch=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                       if(mysqli_stmt_fetch($stmt1)){
                      #tak take soton haye databae ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                ;

                      #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                      ?>
                      <h2><a href='/cms_practice/post.php?p_id=<?php echo $post_id; ?>'><?php echo $post_title; ?></a></h2>
                      <p class='lead'>by <a
                                  href='author.php?author=<?php echo $post_author; ?>'><?php echo $post_author; ?></a>
                      </p>
                      <p><span class='glyphicon glyphicon-time'></span> Posted on <?php echo $post_date; ?></p>
                      <hr>
                      <img class='img-responsive' src='/cms_practice/admin/images/<?php echo $post_image; ?>'
                           alt='<?php echo $post_image; ?>'>
                      <hr>
                      <p><?php echo $post_content; ?></p>
                      <a class='btn btn-primary' href='/cms_practice/post/<?php echo $post_id; ?>'>Read More <span
                                  class='glyphicon glyphicon-chevron-right'></span></a>
                      <hr>


                      <?php

                    }else{
                           echo "<h2 class='alert alert-danger'>There is nothing to Show</h2>";

                       }
                }
                ?>
               
               
        
                
                
               
              

                <hr>

                

                <hr>

                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

    <?php include "includes/sidebar.php";

    #adding sidebar ?>
        <hr>
        
     <?php #adding Footer
     include("includes/footer.php");
     ?>