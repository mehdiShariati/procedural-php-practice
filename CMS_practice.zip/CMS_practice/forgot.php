
<?php  include "includes/header.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader


check_If_user_loggedIn_and_redirect("index");
if(!if_It_is_Method('get') && !isset($_GET['forgot'])){
    redirect('index');
}
if(if_It_is_Method('post')){
    $email=trim_and_Escape_String_mysqli($_POST['email']);
    $length_of_token_experession=50;
    $token=bin2hex(openssl_random_pseudo_bytes($length_of_token_experession));
    if(email_exist($email)){
        $stmt_forgot=mysqli_prepare($connection,"UPDATE users SET token='{$token}' WHERE user_email=?");
        mysqli_stmt_bind_param($stmt_forgot,"s",$email);
        mysqli_stmt_execute($stmt_forgot);
        mysqli_stmt_close($stmt_forgot);


           ##############
#################
###################
############################
############################
#this is section is for PHPMailer who can send msg very well and its awsome by MEHDI SHARIATI
//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
  require 'vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        //Server settings
        //$mail->SMTPDebug = 2;                                       // Enable verbose debug output zamani k disablesh koni dg payam haye debug ro nmide
        $mail->isSMTP();                                            // Set mailer to use SMTP
        $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'mehdishariati12@gmail.com';                     // SMTP username
        $mail->Password   = 'titanboy12';                               // SMTP password
        $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
        $mail->Port       = 587;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('samanekhandan@example.com', 'Mailer');
        $mail->addAddress('mehdishariati12@gmail.com', 'Joe User');     // Add a recipient
        $mail->addAddress('ellen@example.com');               // Name is optional
        $mail->addReplyTo('info@example.com', 'Information');
        $mail->addCC('cc@example.com');
        $mail->addBCC('bcc@example.com');

        // Attachments
        // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        //  $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Here is the subject';
        $mail->Body    = "<p>please click on this link to recover your password<a href='http://localhost:3000/cms_practice/reset.php?email={$email}&token={$token}'>http://localhost:3000/cms_practice/reset.php?email='.$email.'token='.$token'</a></p>";
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        $_SESSION['error_recover_email']=null;
           $_SESSION['recover_email']="For Recover your Password check your Email:".$email;
    } catch (Exception $e) {
        $_SESSION['error_recover_email']= "Message could not be sent. Mailer Error:";
    }
############################################
######################
###############       end of PHP MAILER MEhdi shariati
###########
#############
}else{

        $_SESSION['error_recover_email']="This email not exist";


    }










}

?>
<!-- Page Content -->
<div class="container">

    <div class="form-gap"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                            <?php  if(isset($_SESSION['error_recover_email'])){
                                echo "<h5 class='alert alert-danger loginaa'> {$_SESSION['error_recover_email']} </h5>";
                            }else if(isset($_SESSION['recover_email'])){
                                echo "<h5 class='alert alert-success loginaa'> {$_SESSION['recover_email']} </h5>";
                            } ?>

                            <h3><i class="fa fa-lock fa-4x"></i></h3>
                            <h2 class="text-center">Forgot Password?</h2>
                            <p>You can reset your password here.</p>
                            <div class="panel-body">




                                <form id="register-form" role="form" autocomplete="on" class="form" method="post">

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                            <input id="inputkhali" name="email" placeholder="email address" class="form-control"  type="email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input name="recover-submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
                                    </div>

                                    <input type="hidden" class="hide" name="token" id="token" value="">
                                </form>

                            </div><!-- Body-->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <hr>

    <?php include "includes/footer.php";?>

</div> <!-- /.container -->

