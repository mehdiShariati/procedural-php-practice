<?php  include "includes/header.php"; ?>
<?php
check_If_user_loggedIn_and_redirect("/CMS_practice/");

if(if_It_is_Method('post')) {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];


        $username = trim_and_Escape_String_mysqli($_POST['username']);
        $password = trim_and_Escape_String_mysqli($_POST['password']);


        if (!empty($username) && !empty($password)) {

            Login_user($username, $password);
        } else {

            echo '<h2 class="alert alert-danger text-center">پر کردن فیلد ها اجباریست</h2>';

        }


    }
}



?>









<!-- Page Content -->
<div class="container">

    <div class="form-gap"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">


                            <h3><i class="fa fa-user fa-4x"></i></h3>
                            <h2 class="text-center">Login</h2>
                            <div class="panel-body">

                                <?php  if(isset($_SESSION['error_login'])){
                                    echo "<h5 class='alert alert-danger loginaa'> {$_SESSION['error_login']} </h5>";
                                } ?>
                                <form id="login-form" role="form" autocomplete="on" class="form" method="post">

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-user color-blue"></i></span>

                                            <input name="username" value="<?php if(isset($username)){ echo $username;} ?>" type="text" id="inputkhali" class="form-control" placeholder="Enter Username">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock color-blue"></i></span>
                                            <input name="password" type="password" class="form-control" placeholder="Enter Password">
                                        </div>
                                    </div>

                                    <div class="form-group">

                                        <input name="login" class="btn btn-lg btn-primary btn-block" value="Login" type="submit">
                                    </div>


                                </form>
                                <div class="form-group">
                                    <a href="forgot.php?forgot=<?php echo uniqid(true); ?>">Forgot your Password?</a>
                                </div>

                            </div><!-- Body-->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <hr>

    <?php include "includes/footer.php";?>

</div> <!-- /.container -->
