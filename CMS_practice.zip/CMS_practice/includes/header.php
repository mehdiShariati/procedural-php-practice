<!DOCTYPE html>
<html lang="en">
<?php 
include "db.php";
include ("admin/includes/functions.php");
session_start();
ob_start();
require 'vendor/autoload.php';



?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="/cms_practice/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/cms_practice/css/blog-home.css" rel="stylesheet">
   
    <link href="/cms_practice/css/mystyle.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
  

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a  style="text-decoration:none;" href="./cms_practice/"><?php if(isset($_SESSION['username'])){ ?>
                  <ul class="navbar-brand" style='list-style-type:none;'>
                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown"><i class="fa fa-user"></i><?php if(isset($_SESSION['username'])) { echo  $_SESSION['username'];  } ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                       
                        <li class="divider"></li>
                        <li>
                            <a href="/cms_practice/includes/logout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
                </ul>
                
                <?php
                }
                else{
                     echo "<a class='navbar-brand' href='/cms_practice/registration'>Register</a>";
                    echo "<a class='navbar-brand' href='/cms_practice/Login'>Login</a>";} ?>
                    
               
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                
    <!--

        nahveye fara khani az data base ba code PHP baraye navigtione bala
    -->

<?php
#in tabaro az file functions fetch kardi, va b ye moteqayer assign kardim ta betunim dar jahaye dg ham azash estefade konim
$navigation=call_all_categories_for_navigations_in_front();
?>




<!--
    in qesmat ro baraye badan gozashtam ta link haro ezafe konam 
    -->
                    <?php if(isset($_SESSION['username'])){if(is_admin($_SESSION['username'])){  ?>
                    <li>

                        <a href="/cms_practice/admin/index.php">Admin</a>

                    </li>
                        <?php }} ?>
                    <?php
                    if(isset($_SESSION['role'])) {
                        if ($_SESSION['role'] === "ADMIN") {

                            if (isset($_GET['p_id'])) {


                                echo "<li><a href='/cms_practice/admin/posts.php?posts=update&update={$_GET['p_id']}'>Edit Post</a></li>";
                            }


                        }
                    }

                    
                    
                    ?>


                    <li><a href="/cms_practice/index.php">Home Page</a></li>
                    <li> </li>
                    <li> </li>


                  

            

                </ul>
     
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
   

