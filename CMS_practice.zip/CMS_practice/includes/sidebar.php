
            <!-- Blog Sidebar Widgets Column -->
            <div class="col-md-4">
          

                <!-- Blog Search Well -->
                <div class="well">
                <!-- Form zir ye searche k mishe bahash har posti ro dakhele website search kard va ba methode post ham dare kar mikone be safheye search.php mire -->
                <form action="search.php" method="post">
                    <h4>Blog Search</h4>
                    <div class="input-group">
                        <input name="search" type="text" class="form-control">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="submit" name="submit">
                                <span class="glyphicon glyphicon-login"></span>
                        </button>
                        </form>
                        </span>
                    </div>
                    <!-- /.input-group -->
                </div>



        <!--  THIS LOGIN FORM-->
                            <?php


                            if(!isset($_SESSION['username'])){

                             ?>

                         <div class="well">
                <!-- Form zir Forme logine -->
                            
                            <?php
                            if(isset($_SESSION['error_login'])){
                                echo "<h5 class='alert alert-danger loginaa'> {$_SESSION['error_login']} </h5>";
                            }
                            ?>
                            
                                 <form action="login.php" method="post">
                                 <h4 class="text-center">Login</h4>
                                  <div class="form-group">
                               <input name="username"  type="text"  id="inputkhali" class="form-control">
                                </div>
                                    <div class="input-group">
                                   <input type="password" name="password" class="form-control">
                                  <span class="input-group-btn">
                                  <button class="btn btn-primary" type="submit" name="login">
                                Login
                                </div>
                             </button>
                             </form>

                              </span>
                             <div class="form-group">
                                 <a href="forgot.php?forgot=<?php echo uniqid(true); ?>">Forgot your Password?</a>
                             </div>
                             </div>
                        <?php }else{?>
                          <!-- /.input-group -->
                          <div class="well">
                          <p class="alert">
                            
                            
                            <a class="well" style="text-decoration: none" href="index.php"><?php if(isset($_SESSION['username'])){echo "Wellcome {$_SESSION['username']} | <a class='btn btn-primary' href='includes/logout.php?logout'>logout</a>";}else echo "Home Page"; ?></a>
                            </p>
                          </div>
                        <?php }?>
             




                
             
                   



















                   <!-- Blog Categories Well -->
                <div class="well text-center">
                    <h4>Blog Categories</h4>
                    <div class="row text-center">
                        <div class=" text-center" >
                            <ul class="list-unstyled text-center" style="display:inline-block;text-align:center">
                              <?php
                        //      $query="SELECT * FROM categories";
                       //      $result_categoriess=mysqli_query($connection,$query);
                        //     if(!$result_categoriess){
                        //         die(mysqli_error($connection));
                          //   }

                         //   $stmt_category_for_sideBar=mysqli_prepare($connection,"SELECT cat_id,cat_title FROM categories");
                        //      if($stmt_category_for_sideBar == false) {
                         //         die("<pre>".mysqli_error($connection)."</pre>");
                          //    }

                          //    mysqli_stmt_execute($stmt_category_for_sideBar);
                         //   mysqli_stmt_bind_result($stmt_category_for_sideBar,$id_category,$title);











                         //    mysqli_stmt_fetch($stmt_category_for_sideBar);
                              #moteqayere $navigation ro dakhele header farkahani kardim va inja ba ye halqe dobre prinesh kardim baraye side baremon
                             foreach($navigation as $nav){
                                 echo $nav;
                             }

                              //   ?>

                            </ul>
                        </div>
                  
                    </div>
                    <!-- /.row -->
          
                </div>
                <?php
             include "includes/widget.php";
             ?>   
            
           
 
        <!-- /.row -->

        