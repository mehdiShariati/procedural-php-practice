
</div>
<!-- Footer -->
   <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; By Mehdi Shariati</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="/cms_practice/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/cms_practice/js/bootstrap.min.js"></script>
    <script>
    // in code javascripto baraye in neveshtam k ta click kardim error haye login pak bshe
    var selecterror=document.querySelector(".loginaa");
    var clicktext=document.querySelector("#inputkhali");

    clicktext.addEventListener('click',()=>{
        selecterror.style.display="none";
    

    },false);
    </script>

</body>

</html>
