<?php
# in bakhsh baraye etesal b database neveshtam va say kardam az motaqeyer ha estefade konam baraye function connect mysqli ta betunam ba
# kamtarin khata be data base motasel besham

$db["UserName"]="root";
$db["PassWord"]="1234";
$db["Server"]="localhost:3306";
$db["Db_name"]="my_cms";
#ba estefade az foreach moteqayer haye vorodi ro be sorate constant tarif kardam ta qabele taqir nabashe va baese ijade khata nashe
foreach ($db as $key => $value) {
    define(strtoupper($key), $value);   
}
#functione etesal b data base k vorodi hash ro ba sabet hayi k bala tarif kardam vared kardam
$connection=mysqli_connect(SERVER,USERNAME,PASSWORD,DB_NAME);
#agar khatayi bashe in code be ma neshun mide mysqlii_error($connectio n)
if(!$connection){

     die(mysqli_error($connection));
}







?>