<?php 
session_start();

if(isset($_GET['logout'])){
    $_SESSION['error_login']=null;
    $_SESSION['username']=null;
    $_SESSION['role']=null;
    header("Location:../index.php");

}



?>