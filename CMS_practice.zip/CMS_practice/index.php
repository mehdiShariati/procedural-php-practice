<?php
#adding Header
include("includes\header.php");
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function


if(isset($_GET['page'])){
    #code zir baraye daryaft safhye ya linki k pagination b safhe inde mide estefade mishe 
    $page=$_GET['page'];

}else{
    #agar url index.php khali bud khudemon b $page ye meqdar midim chun to farakhani tavabe azash estefade mishavad
    $page="";
}
?>


<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8" dir="rtl">
                <?php
                #query zir ro baraye be dast avordane teadde post ha estefade mishe 
                    $query_For_count_rows="SELECT * FROM posts where post_status='Publish'";
                    $result_count_rows=mysqli_query($connection,$query_For_count_rows);
                    #code zir baraye shemordane teadde post hast
                    $count=mysqli_num_rows($result_count_rows);
                    #code zir baraye ine k rond konim teade post ha ro masalan code zir mige teadd post ha taqsim bar 4 bshe
                    #va functione floor baraye gerd kardane adad b samte paeen estefade mishe  
                      $count=floor($count / 4);

                      if($page ==1 || $page==""){

                        $page_1=0;
                    }else{
                
                        $page_1=($page * 4)-4;
                    }
                
                ?>

             
                <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
                in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
                <!--  Blog Post -->
                <?php 
                    #query bara farakhani post ha tavasote pagination k bad az LIMIT parametr aval OFFSET 
                    #ya hamon teadide k bayad ja bendazim va parametre dovom tedad post hayi k bayad ba in query farakhani bshe
                    $query="SELECT * FROM posts where post_status='Publish' LIMIT  $page_1,4";
                    #functione query baraye ejraye query neveshte shude be samte data base
                    $result_post_fetch=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                    if($result_post_fetch){



                   while($row=mysqli_fetch_assoc($result_post_fetch)){
                       #tak take soton haye database ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                 $post_title=$row['post_title'];
                    $post_content=substr($row['post_content'],0,30);
                    $post_date=$row["post_date"];
                    $post_author=$row["post_author"];
                    $post_image=$row['post_image'];
                    $post_id=$row['post_id'];
                    $post_view_count=$row['post_views_count'];


                   $query_for_count_comment_of_posts="SELECT * FROM comments WHERE comment_post_id = '{$post_id}' and comment_status='APPROVE' ";
                   $result_qury_count_cm=mysqli_query($connection,$query_for_count_comment_of_posts);
                   $post_cm_count=mysqli_num_rows($result_qury_count_cm);

                    #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                    ?>
                    <h2> <a href='post.php?p_id=<?php echo $post_id; ?>'><?php echo $post_title; ?></a></h2>  
                   <p class='lead'>نوشته شده توسط  <a href='author.php?author=<?php echo $post_author; ?>'><?php echo $post_author; ?></a></p>
                   <p><span class='glyphicon glyphicon-time'></span>منتشر شده در تاریخ: <?php echo $post_date; ?></p><hr>
                   <img class='img-responsive' src='admin/images/<?php echo $post_image; ?>' alt='<?php echo $post_image; ?>'><hr>
                    <p><?php echo $post_content." ...."; ?></p>
                    
                    <p style="font-size:18px;"><span class="glyphicon glyphicon-comment"></span> <?php echo $post_cm_count; ?> <span>نظر</span>&nbsp;&nbsp;<i class="fas fa-eye"></i><?php echo $post_view_count; ?> <span>بازدید</span></p>

                    <a class='btn btn-primary'= href='post.php?p_id=<?php echo $post_id; ?>'>ادامه مطلب <span class='glyphicon glyphicon-chevron-left'></span></a><hr>



                    <?php
                   }
                }else{
                    echo "ERROR";
                }
                
                ?>
               
               
        
                
                
               
              

                <hr>

                

                <hr>
                
                <!-- Pager
            in bakhsh baraye paginatione in safhas va be ezaye tedade post ha baraye ma link ejad mikone ta betunim pagination dashte bashim
                 -->
                <ul class="pager" dir="ltr">
       
                <?php 
                for ($i=1; $i <=$count+1 ; $i++) {
                    if($i==$page){
                    
                    echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";
                    }else{

                        echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
                    }
                    
                }
                
                
                
                ?>





                </ul>

            </div>

    <?php include "includes/sidebar.php";
       
    #adding sidebar ?>
        <hr>
        </div>
     <?php #adding Footer
     include("includes/footer.php");
     ?>