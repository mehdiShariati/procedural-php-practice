<?php
#adding Header
include("includes\header.php");

?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>
                <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
                in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
                <!--  Blog Post -->
                <?php 

                
                    if(isset($_POST["submit"])){
                     $search=$_POST["search"];


                      

        






                    #query bara farakhani post haeye search shude
                    $query="SELECT * FROM posts where post_tags like '%$search%'";
                    #functione query baraye ejraye query neveshte shude be samte data base
                    $result_post_search=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                   while($row=mysqli_fetch_assoc($result_post_search)){
                       #tak take soton haye database ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                 $post_title=$row['post_title'];
                    $post_content=$row['post_content'];
                    $post_date=$row["post_date"];
                    $post_author=$row["post_author"];

                    #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                    ?>
                    <h2> <a href='#'><?php echo $post_title; ?></a></h2>  
                   <p class='lead'>by  <a href='index.php'><?php echo $post_author; ?></a></p>
                   <p><span class='glyphicon glyphicon-time'></span> Posted on <?php echo $post_date; ?></p><hr>
                   <img class='img-responsive' src='http://placehold.it/900x300' alt=''><hr>
                    <p><?php echo $post_content; ?></p>
                    <a class='btn btn-primary'= href='#'>Read More <span class='glyphicon glyphicon-chevron-right'></span></a><hr>



                    <?php
                   }
                
                
                }
                #khate code paeen miad cheak mikone age neveshteyi k search karde budi dakhele data base nabud onvaqt miad ye chi b karbar neshun mikde mige k yaft nashud
                  if(mysqli_num_rows($result_post_search)=== 0){
                   

                    echo "<h2>NO RESULTS FOUND FOR <a href='#'>{$search}</a>";



                }
                
                ?>
               
               
        
                
                
               
              

                <hr>

                

                <hr>

                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>

            </div>

    <?php include "includes/sidebar.php"; 
    #adding sidebar ?>
        <hr>
        
     <?php #adding Footer
     include("includes/footer.php");
     ?>