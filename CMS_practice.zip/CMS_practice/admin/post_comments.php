<?php
    include "includes/header.php";
    include "includes/navigation.php"; 
    #include Header

    ?>

    <div id="wrapper">

        <!-- Navigation -->
   


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                          Welcome Back 
                            <small>Author</small>
                            <?php echo date('Y-M-d h:i:s a'); ?>
                        </h1>
                <?php
                       if(isset($_GET['p_id'])){
                        $p_id=$_GET['p_id'];

                       
                       ?>
                        <table class="table table-bordered table-hover" style="width=100%">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Author</th>
                            <th>Content</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>in Response To</th>
                            <th>date</th>
                            <th>Approve</th>
                            <th>Unapprove</th>
                            <th colspan=2>Operation</th>
                        </tr>
                        
                        </thead>
                     <tbody>
                     <?php
                   
                     call_specific_comments($p_id);
                     ?>
                     
                     </tbody>
                        
                        
                        
                        </table>
                    


                        <?php
                    }else {
                        $p_id="";

                        echo "<h5 class='alert alert-danger'>There is n't Selected any post</h5>";

                        
                    }
                    

                    ?>
















                       <?php


                 
                    if(isset($_GET['delete'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $del_id=$_GET['delete'];
                        $query="DELETE from comments where comment_id='{$del_id}'";
                        $result_del_comments=mysqli_query($connection,$query);
                        confirmQuery($result_del_comments);
                        header("location:post_comments.php?p_id={$_GET['p_id']}");

                            }
                        }

                    }
                    if(isset($_GET['approveokID'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $approveOkId=$_GET['approveokID'];
                    $query_for_approve_cms="UPDATE comments SET comment_status='APPROVE' where comment_id={$approveOkId}";
                    $result_query_approve=mysqli_query($connection,$query_for_approve_cms);
                    confirmQuery($result_query_approve);
                    header("location:post_comments.php?p_id={$_GET['p_id']}");



                            }}
                    }
                    if(isset($_GET['approveNokkID'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $unApproveId=$_GET['approveNokkID'];
                    $query_for_unapprove_a_comment="UPDATE comments Set comment_status='UNAPPROVE' where comment_id={$unApproveId}";
                    $result_query_unapprove_a_cm=mysqli_query($connection,$query_for_unapprove_a_comment);
                    confirmQuery($result_query_unapprove_a_cm);
                    header("location:post_comments.php?p_id={$_GET['p_id']}");


                            }
                        }

                    }

                            ?>

           
                    
                    

                    </div>
                 
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

  <?php include "includes/footer.php"; ?>