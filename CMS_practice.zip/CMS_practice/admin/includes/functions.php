<?php




function redirect($location){
    header("Location:".$location);
    exit();
}

function if_It_is_Method($method=null){
    if ($_SERVER['REQUEST_METHOD'] === strtoupper($method)){
            return true;
    }else{
        return false;
    }
}
function isLoggedIn(){
    if(isset($_SESSION['role'])){
        return true;
    }
    else{


        return false;
    }


}
function check_If_user_loggedIn_and_redirect($redirectLocation){
    if(isLoggedIn()){
        redirect($redirectLocation);
    }

}

function is_admin($username) {

    global $connection;

    $query = "SELECT user_role FROM users WHERE user_name = '$username'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    $row = mysqli_fetch_array($result);


    if($row['user_role'] === 'ADMIN'){

        return true;

    }else {


        return false;
    }

}



function trim_and_Escape_String_mysqli($string){
    #az in code ha baraye jelogiri az hack ya query injection estefade mishe
    global $connection;
    return trim(mysqli_real_escape_string($connection,$string));
}
function confirmQuery($result){
global $connection;
if(!$result){

die(mysqli_error($connection));

}

}
function Login_user($username,$password){


//        #in code baraye farakhani methode ramznegari password ha az database estefade mishe ke estelahan behesh migan salt methode crypt ham SHA-512
//       #passworde vorodi karbar ro ba kilid haye ramz negari khudemon ramznegarish kardm ta eynan moshabehe passworde karbar bshe
//       $query_for_fetch_salt_From_database="Select randSalt from users";
//       $result_fetch_randsalt=mysqli_query($connection,$query_for_fetch_salt_From_database);//        while($row=mysqli_fetch_assoc($result_fetch_randsalt)){
//           $salt=$row['randSalt'];
    //      }
//       $password=crypt($password,$salt);
    // in yek no ramz negari jadide k behtare az methode crypt kar mikone

#--- When A User Wants To Sign In ---
#1 ---> Get Input From User Which Is The User`s Password
#2 ---> Fetch The Hashed Password From Your Database
#3 ---> Compare The User`s Input And The Hashed Password with methode password_verify(first field is password,second is password fetched from database);
#
#
#
    global $connection;
    $query_for_check_username_and_password="SELECT * FROM users where user_name='{$username}'";
    $result_query_check_uname_pass=mysqli_query($connection,$query_for_check_username_and_password);
    if(mysqli_num_rows($result_query_check_uname_pass)==0){
        header("Location:../index.php");
        $_SESSION['error_login']="نام کاربری یا رمز عبور اشتباه است";
        die(redirect("/CMS_practice/login"));
        exit;
    }else{

        while($row=mysqli_fetch_array($result_query_check_uname_pass)){
            $db_username=$row['user_name'];
            $db_password=$row['user_password'];
            $db_role=$row['user_role'];
        }
    }
    if($db_username === $username && password_verify($password,$db_password)){
        $_SESSION['error_login']=null;
        $_SESSION['username']=$db_username;
        $_SESSION['role']=$db_role;

        if(is_admin($username)){
            redirect("/CMS_practice/admin");
        }else{
            redirect("/CMS_practice/");
        }

    }else{
        $_SESSION['error_login']="رمز عبور اشتباه است";
       redirect("/CMS_practice/login");
    }
















}














function email_exist($email)
{

    global $connection;
    #in code baraye farakhani va validate kardane email estefade mishe k tavasote on mitunim check konim bbinim chenin useri vojud dare ya na
    $query_for_check_email = "SELECT * FROM users where  user_email='{$email}'";
    $result_check = mysqli_query($connection, $query_for_check_email);
    if (mysqli_num_rows($result_check) > 0) {

        return true;

    } else {

        return false;


    }

}




function pagination($page,$count){




    for ($i=1; $i <=$count+1 ; $i++) {
        if($i==$page){

            echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";
        }else{

            echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
        }

    }





}
function check_username_and_email($username,$email){
    global $connection;
    #in code baraye farakhani va validate kardane username va email estefade mishe k tavasote on mitunim check konim bbinim chenin useri vojud dare ya na
    $query_for_check_uname_and_email="SELECT * FROM users where user_name='{$username}' or user_email='{$email}'";
    $result_check=mysqli_query($connection,$query_for_check_uname_and_email);
    if(mysqli_num_rows($result_check) > 0){
        while($row=mysqli_fetch_assoc($result_check)){
            $db_username=$row['user_name'];
            $db_user_email= $row['user_email'];
            if($username == $db_username){
                echo "This User Name already Exist Please Try another One";
                return false;
            }
            else{
                echo "This Email already Exist Please Try another One";
                return false;
            }

        }



    }else{
        return true;
    }

}
function Insert_user_query($username,$email,$password,$user_register_date){
       global $connection;
    $query = "INSERT INTO users (user_name,user_password,user_email,user_role,user_register_date) ";
    $query .= "VALUES ('{$username}','{$password}','{$email}','Subscriber','{$user_register_date}')";
    $Insert_user_result = mysqli_query($connection, $query);
    if (!$Insert_user_result) {
        die(mysqli_error($connection));
    } else {
        echo "<h4 class='alert alert-success'>You Registered Successfully</h4>";
        return true;
    }
}

function validate_and_encryption_password($password){
        if(empty($password)){
            echo "Password Cannot be Empty";
            return false;
        }
        if(strlen($password)<5){
            echo "password Too short";
            return false;
        }
    if(!empty($password) && strlen($password)>5) {
        return $password = password_hash($password, PASSWORD_BCRYPT, array('cost' => 12));
    }else{

        return false;
    }
}











function call_all_post_with_pagination($page){

                global $connection;
               #query zir ro baraye be dast avordane teadde post ha estefade mishe
                    $query_For_count_rows="SELECT * FROM posts where post_status='Publish'";
                    $result_count_rows=mysqli_query($connection,$query_For_count_rows);
                    #code zir baraye shemordane teadde post hast
                    $count=mysqli_num_rows($result_count_rows);
                    #code zir baraye ine k rond konim teade post ha ro masalan code zir mige teadd post ha taqsim bar 4 bshe
                    #va functione floor baraye gerd kardane adad b samte paeen estefade mishe
                      $count=floor($count / 4);

                      if($page ==1 || $page==""){

                        $page_1=0;
                    }else{

                        $page_1=($page * 4)-4;
                    }




              #  <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
               # in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
              #  <!--  Blog Post -->

                    #query bara farakhani post ha tavasote pagination k bad az LIMIT parametr aval OFFSET
                    #ya hamon teadide k bayad ja bendazim va parametre dovom tedad post hayi k bayad ba in query farakhani bshe
                    $query="SELECT * FROM posts where post_status='Publish' LIMIT  $page_1,4";
                    #functione query baraye ejraye query neveshte shude be samte data base
                    $result_post_fetch=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                    if($result_post_fetch){



                   while($row=mysqli_fetch_assoc($result_post_fetch)){
                       #tak take soton haye database ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                 $post_title=$row['post_title'];
                    $post_content=substr($row['post_content'],0,30);
                    $post_date=$row["post_date"];
                    $post_author=$row["post_author"];
                    $post_image=$row['post_image'];
                    $post_id=$row['post_id'];
                    $post_view_count=$row['post_views_count'];


                   $query_for_count_comment_of_posts="SELECT * FROM comments WHERE comment_post_id = '{$post_id}' and comment_status='APPROVE' ";
                   $result_qury_count_cm=mysqli_query($connection,$query_for_count_comment_of_posts);
                   $post_cm_count=mysqli_num_rows($result_qury_count_cm);

                    #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                    ?>
                    <h2> <a href='post/<?php echo $post_id; ?>'><?php echo $post_title; ?></a></h2>
                   <p class='lead'>نوشته شده توسط  <a href='author.php?author=<?php echo $post_author; ?>'><?php echo $post_author; ?></a></p>
                   <p><span class='glyphicon glyphicon-time'></span>منتشر شده در تاریخ: <?php echo $post_date; ?></p><hr>
                   <img class='img-responsive' src='/cms_practice/admin/images/<?php echo $post_image; ?>' alt='<?php echo $post_image; ?>'><hr>
                    <p><?php echo $post_content." ...."; ?></p>

                    <p style="font-size:18px;"><span class="glyphicon glyphicon-comment"></span> <?php echo $post_cm_count; ?> <span>نظر</span>&nbsp;&nbsp;<i class="fas fa-eye"></i><?php echo $post_view_count; ?> <span>بازدید</span></p>

                    <a class='btn btn-primary'= href='post/<?php echo $post_id; ?>'>ادامه مطلب <span class='glyphicon glyphicon-chevron-left'></span></a><hr>


                <?php

                   }
                }else{
                    echo "ERROR";
                }


                return $count;

}



























function call_specific_comments($p_id){
    global $connection;
    $query="SELECT * FROM comments where comment_post_id='{$p_id}' ORDER BY comment_id DESC";
    $result_query_comments=mysqli_query($connection,$query);
    if(!$result_query_comments){
        
    
    die(mysqli_error($connection));
    
    }
    if(mysqli_num_rows($result_query_comments) <= 0){
        
        echo "<h5 class='alert alert-danger'>There is n't Selected any post</h5>";
    }
    while($row=mysqli_fetch_assoc($result_query_comments)){
    $comment_id=$row['comment_id'];
    $comment_post_id=$row['comment_post_id'];
    $comment_author=$row['comment_author'];
    $comment_email=$row['comment_email'];
    $comment_content=$row["comment_content"];
    $comment_status=$row['comment_status'];
    $comment_date=$row['comment_date'];

    echo "<tr>";
    echo "<td>{$comment_id}</td>";
    echo "<td>{$comment_author}</td>";
    echo "<td>{$comment_content}</td>";
    echo "<td>{$comment_email}</td>";
    echo "<td>{$comment_status}</td>";
    #query baraye farakhani posti k dakhelesh comment gozashte shude 
    $QUERY_FOR_CALL_Post_comments_response_to="SELECT * FROM posts WHERE post_id={$comment_post_id}";
    $result_query_call_post_comments_Response_to=mysqli_query($connection,$QUERY_FOR_CALL_Post_comments_response_to);
    while ($bow=mysqli_fetch_array($result_query_call_post_comments_Response_to)) {
        $post_title=$bow['post_title'];
        $post_id=$bow['post_id'];
        
    }
    
    
    
    echo "<td><a href='../post.php?p_id={$post_id}'>{$post_title}</a></td>";
    echo "<td>{$comment_date}</td>";
    #id in comment ha ro ersal mikonim ta ba on betunim query bzanim va approve ya un approveshun konim
    echo "<td><a href='post_comments.php?approveokID={$comment_id}&p_id={$post_id}' class='btn btn-success'>Approve</a></td>";
    echo "<td><a href='post_comments.php?approveNokkID={$comment_id}&p_id={$post_id}' class='btn btn-info'>UnApprove</a></td>";



    
    echo "<td><a class='btn btn-danger' href='post_comments.php?delete={$comment_id}&p_id={$post_id}'>Delete</a></td>";
   
    echo"</tr>";
    
    
    
    
    }
    



    
}



function qtfy_user_online(){
      #this section is for user ONline COunt
      #ye darkhaste https GET az tarafe ajax miad k key hast onlineuser ma ono check mikonim va chun mosataqim omadim to in safhe be $connection dastresi nadarim
      #ye shart gozashtim k check konim agar dastresi nadasht mostaqim database ro include konim ta betunim query hamono anjam bdim va session ro ham start kardim
      if(isset($_GET['onlineuser'])){
      global $connection;
      if(!$connection){
          session_start();
          include("../../includes/db.php");
     
      #to in qesmat id sessioni k active shude bara karbar ro migirm ta bebarim bahash query bezanim to database
      $session=session_id();
      $time=time();
      #agar meqdare in moteqayere zir ro taqir bdim online user ro bar hasbe on mishmore mige k age kasi alan dakhele website a az akharin bazdide site ma
      #yek deqe nagzashte on ro be onvane karbare online dar nazar begir
      $timeout_user_to_secend=15;
      $timeout=$time-$timeout_user_to_secend;


      #ba query zir miad cheak mikone bbine in karbari k alan omade sessionesh toye data base hast ya na
      $query_for_find_Session="SELECT * FROM users_online WHERE session='{$session}'";
      $result_query_find_Session=mysqli_query($connection,$query_for_find_Session);
      #ba dastore zir check mikone mige agar nabud bia khudet ba query paeenesh add kon 
      if(mysqli_num_rows($result_query_find_Session)<=0){
  
              mysqli_query($connection,"INSERT INTO users_online (session,time) VALUES ('{$session}','{$time}')");
  
      }else{
        #dar qeyre in sorat mige agar sessionesh bud bia updatesh kon va timesh ro ziad kon ta beonvane karbare online shenakhte bshe
          mysqli_query($connection,"UPDATE users_online SET time='{$time}' WHERE session='{$session}'");
      }
      #ba code zir ham mishamrim tedade user haye online ro 
      $count_user_online=mysqli_query($connection,"SELECT * FROM users_online WHERE time > $timeout");
      echo $qtfy_users_online= mysqli_num_rows($count_user_online);
    }
}
     
}

#chun ba ajax mostaqim omadim to in file bara hamon bayad tabeye bala ro k neveshtim yek bar ejra konim k baraye shemordane tedade user haye online
qtfy_user_online();

function Insert_categories(){
    global $connection;
    if(isset($_POST['submit'])){
     
        $ftitle = $_POST['cat_title'];
        
        if($ftitle =="" || empty($ftitle)){

        echo $result= "<p class='alert alert-danger' dir='rtl' >فیلد نام دسته بندی خالی است   </p>";


        }else{
            #query insert be table category ha bstatement neveshte shude ke bsyar karbordi va javab ast chun amn tar nesbat b attack haye sql injection
        $stmt_insert_cat=mysqli_prepare($connection,"INSERT INTO categories(cat_title) VALUE (?)");
         mysqli_stmt_bind_param($stmt_insert_cat,"s",$ftitle);
         mysqli_stmt_execute($stmt_insert_cat);
         
            
        echo    $result="<p class='alert alert-success' dir='rtl' > دسته بندی با موفقیت ثبت شد </p>";
        }
         






     }





}




function Delete_category(){
            global $connection;
                 # this is for deleting a category from data base with my hand code , khate code paeen mige age ba methode get omadi be n safhe va delcat por bud tabe zir ro ejra kon 
                 if(isset($_GET['delcat'])){

                    $del=$_GET['delcat'];

                $query_delete="DELETE from categories where cat_id = '{$del}'";
                $del_Result=mysqli_query($connection,$query_delete);
                if($del_Result){
                    echo "<p class='alert alert-success' dir='rtl' > دسته بندی با موفقیت حذف شد </p>";
                    header("Location:categories.php");

                }else{

                    echo "<p class='alert alert-danger' dir='rtl' >مشکلی رخ داده است </p>";
                }





                }



}
#BARAYE FARAKHANI category ha az data base
function CALL_categories(){
     #be dalile inke darim dakhele function a connectione data base estefade mikonim hatman bayad on ro global konim

    global $connection;

                 #query baraye fetch kardane tamame soton haye jadvale category to safhe admin
                 $query="SELECT * FROM categories";
                 $result_query_cat=mysqli_query($connection,$query);
        # in khate code baraye namayesh dadeha az data base estefade mishe va ba in halqe ba api mysqli be rahati namayesh midim dadeha ro

          while($row=mysqli_fetch_assoc($result_query_cat)){
            $title= $row["cat_title"];
            $Id= $row["cat_id"];
            echo "<tr>";
            echo  "<td>{$Id}</td>";
            echo  "<td>  {$title} </td>";
            echo "<td class='text-center'><a class='btn btn-danger' href='categories.php?delcat={$Id}'>Delete</a></td>";
            echo "<td class='text-center'><a class='btn btn-primary' href='categories.php?update={$Id}'>Update</a></td>";
            echo "</tr>";
        }
         
}
function  call_all_comments(){
    global $connection;
    $query="SELECT * FROM comments ORDER BY comment_id DESC";
    $result_query_comments=mysqli_query($connection,$query);
    if(!$result_query_comments){
        
    
    die(mysqli_error($connection));
    
    }
    while($row=mysqli_fetch_assoc($result_query_comments)){
    $comment_id=$row['comment_id'];
    $comment_post_id=$row['comment_post_id'];
    $comment_author=$row['comment_author'];
    $comment_email=$row['comment_email'];
    $comment_content=$row["comment_content"];
    $comment_status=$row['comment_status'];
    $comment_date=$row['comment_date'];

    echo "<tr>";
    echo "<td>{$comment_id}</td>";
    echo "<td>{$comment_author}</td>";
    echo "<td>{$comment_content}</td>";
    echo "<td>{$comment_email}</td>";
    echo "<td>{$comment_status}</td>";
    #query baraye farakhani posti k dakhelesh comment gozashte shude 
    $QUERY_FOR_CALL_Post_comments_response_to="SELECT * FROM posts WHERE post_id={$comment_post_id}";
    $result_query_call_post_comments_Response_to=mysqli_query($connection,$QUERY_FOR_CALL_Post_comments_response_to);
    while ($bow=mysqli_fetch_array($result_query_call_post_comments_Response_to)) {
        $post_title=$bow['post_title'];
        $post_id=$bow['post_id'];
        
    }
    
    
    
    echo "<td><a href='../post.php?p_id={$post_id}'>{$post_title}</a></td>";
    echo "<td>{$comment_date}</td>";
    #id in comment ha ro ersal mikonim ta ba on betunim query bzanim va approve ya un approveshun konim
    echo "<td><a href='comments.php?approveokID={$comment_id}' class='btn btn-success'>Approve</a></td>";
    echo "<td><a href='comments.php?approveNokkID={$comment_id}' class='btn btn-info'>UnApprove</a></td>";



    
    echo "<td><a class='btn btn-danger' href='comments.php?delete={$comment_id}'>Delete</a></td>";
   
    echo"</tr>";
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    }
    
    
    
    
    
    
    
    }
    #baraye farakhani jadvale users az database estefade mishe
function call_all_users(){
global $connection;
$query_for_call_all_users="SELECT * FROM users";
$result_query_call_users=mysqli_query($connection,$query_for_call_all_users);
confirmQuery($result_query_call_users);
while($row=mysqli_fetch_assoc($result_query_call_users)){
$user_id=$row['user_id'];
$user_name=$row['user_name'];
$user_image=$row['user_image'];
$user_firstname=$row['user_firstname'];
$user_email=$row['user_email'];
$user_role=$row['user_role'];
$user_register_date=$row['user_register_date'];

echo "<tr>";
echo "<td>{$user_id}</td>";
echo "<td>{$user_name}</td>";
echo "<td>{$user_firstname}</td>";
echo "<td><img src='images/{$user_image}' class='img-responsive' width='100'></td>";
echo "<td>{$user_email}</td>";
echo "<td>{$user_role}</td>";
echo "<td>{$user_register_date}</td>";

echo "<td><a class='btn btn-info' href='users.php?chngtoadmin={$user_id}'>Admin</a></td>";
echo "<td><a class='btn btn-primary' href='users.php?chngtosub={$user_id}'>Subscriber</a></td>";
echo "<td><a class='btn btn-danger' href='users.php?user=update&edit_user={$user_id}'>Edit</a></td>";
echo "<td><a class='btn btn-danger' href='users.php?delete={$user_id}'>Delete</a></td>";
echo "</tr>";



}






}

function call_all_categories_for_navigations_in_front(){
    global $connection;
    #yek araye tarif mikonim va meqdar haye fetch shudaro dakhele in araye zakhire mikonim ta badan betunim azash estefade konim
    $nav[0]="";
    $i=0;
    #in code ha baraye farakhani menu az data base ast va ba ezafe kardane ya hamon include db dar balaye safhe be rahati mitavan
#menu ha ra az data base farakhani kard va inja insert kard
    $query="Select * from categories";
    $query_for_select_categories_from_database=mysqli_query($connection,$query);
#ba in halqe while va ba komake methode mysqli fetch assoc mishavad qeury zade shude ra msle key value az database biron keshid
    while ($row=mysqli_fetch_assoc($query_for_select_categories_from_database)) {
        $cat_title=$row['cat_title'];
        $category_id=$row['cat_id'];
        echo "<li><a href='/cms_practice/category/{$category_id}'>{$cat_title}</a><li>";
        $nav[$i]="<li><a href='/cms_practice/category/{$category_id}'>{$cat_title}</a><li>";
        $i++;
    }


#va maqadire fetch shudeye navigation ro dakhele yek araye zakhire mikonim va ta betunim harja k mikhaym azash estefade konim
return $nav;

}




function call_all_posts(){
    global $connection;
//$query="SELECT * FROM posts";

    //$QUERY_FOR_CALL_CATEGORY_TITLE="SELECT * FROM categories WHERE cat_id={$post_category_id}";
//$result_query_call_cat_title=mysqli_query($connection,$QUERY_FOR_CALL_CATEGORY_TITLE);
//while ($row=mysqli_fetch_assoc($result_query_call_cat_title)) {


//}


    #az query zir barae join zadane 2 ta table posts va categories estefade shude k methodesh ham LEft join bude va ba inkar ba  yek query kole dadehaye made nazareto
    #farakhani mikoni va be jaye 2 ta query bala az in code estefade mikoni
    $query="SELECT posts.post_id, posts.post_author , posts.post_title, posts.post_category_id, posts.post_date, posts.post_image, posts.post_content, posts.post_tags, posts.post_status,";
    $query .=" posts.post_views_count, categories.cat_id, categories.cat_title ";
    $query .="FROM posts ";
    $query .="LEFT JOIN categories ON posts.post_category_id = categories.cat_id ORDER BY posts.post_id DESC";






$result_query_posts=mysqli_query($connection,$query);
if(!$result_query_posts){

die(mysqli_error($connection));

}
while($row=mysqli_fetch_assoc($result_query_posts)){
$post_id=$row['post_id'];
$post_category_id=$row['post_category_id'];
$post_title=$row['post_title'];
$post_author=$row['post_author'];
$post_date=$row["post_date"];
$post_image=$row['post_image'];
$post_content=$row['post_content'];
$post_tags=$row['post_tags'];
$cat_title=$row['cat_title'];
#this section is for counting comments for demonstrate comment count in post table
$query_for_count_cm="SELECT * FROM comments where comment_post_id ='{$post_id}'";
$result_query_cm_count=mysqli_query($connection,$query_for_count_cm);
$post_comment_count=mysqli_num_rows($result_query_cm_count);








$post_status=$row['post_status'];
$post_views_count=$row['post_views_count'];
echo "<tr>";
?>
<td><input type="checkbox" class='checkBoxes' name="allSelectedIds[]" value="<?php echo $post_id; ?>"> </td>
<?php
echo "<td>{$post_id}</td>";




echo "<td>{$cat_title}</td>";
















echo "<td>{$post_title}</td>";
echo "<td>{$post_author}</td>";
echo "<td>{$post_date}</td>";
echo "<td><img width='100' class='img-responsive' src='images/{$post_image}'></td>";
echo "<td>{$post_content}</td>";
echo "<td>{$post_tags}</td>";
echo "<td><a href='post_comments.php?p_id={$post_id}'>{$post_comment_count}</td>";
echo "<td>{$post_status}</td>";
echo "<td>{$post_views_count}</td>";
#methode onclike zir yek no escape k ye alert popup baz mikone va age ok bdi dastore anchor tag ro ejra mikone dar qeyre in sorat cancelesh mikone
echo "<td><a class='btn btn-danger' onClick=\"javascript: return confirm('Are You Sure to Delete This Post?'); \" href='posts.php?delete={$post_id}'>Delete</a></td>";
echo "<td><a class='btn btn-primary' href='posts.php?posts=update&update={$post_id}'>Update</a></td>";
echo "<td><a class='btn btn-primary' href='/cms_practice/post/{$post_id}'>view</a></td>";
echo"</tr>";






















}







}





?>

          


