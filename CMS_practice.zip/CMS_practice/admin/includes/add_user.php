

                    <?php 
                    if(isset($_POST['add-user'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){

                        $user_name=$_POST['user_name'];
                        $user_firstname=$_POST['user_firstname'];
                        $user_email=$_POST['user_email'];
                        $user_password=$_POST['user_password'];
                        $user_role=$_POST['user_role'];
                        $user_register_date= date('y-m-d');
                            #hash password with this method first the password who recieved from user input and secend is hash algoritm and last is lenth of Encription
             
                        $user_password= password_hash($user_password,PASSWORD_BCRYPT,array('cost'=>12));



                        $query="INSERT INTO users (user_name,user_password,user_firstname,user_email,user_role,user_register_date) ";
                        $query.="VALUES ('{$user_name}','{$user_password}','{$user_firstname}','{$user_email}','{$user_role}','{$user_register_date}')";
                        $Insert_user_result=mysqli_query($connection,$query);
                        confirmQuery($Insert_user_result);
                        echo "<a href='users.php' class='alert alert-success'>User Created_Successfully.Click Here TO see All users</a>";
                     



                    }
                }
            }
                    
                    
                
                    
                    ?>





            
                       <div class="form-group text-right">
                       <form  action="" method="post" enctype="multipart/form-data">
                       <div class="form-group text-center">
                       <label for="user_name" dir="rtl">نام کاربری</label>
                       <input type="text" name="user_name" class='form-control text-right' placeholder="لطفا عنوان پست را اینجا بنوسید">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_firstname" dir="rtl">نام و نام خانوادگی کاربر</label>
                       <input type="text" name="user_firstname" class='form-control text-right' placeholder="لطفا نام نویسنده پست را اینجا بنوسید">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_email" dir="rtl">ایمیل کاربر</label>
                       <input type="email" name="user_email" class='form-control text-right' placeholder="لطفا کلمات کلیدی پست را اینجا بنوسید">
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="user_password" dir="rtl">رمز عبور</label>
                        <input type="password" name="user_password" class="form-control">
                       
                       </div>
                   
               
                       
               
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_role" dir="rtl"> نقش کاربر</label>
                       <select  name="user_role" class='form-control text-right'>
                        <option value="subscriber"> کاربر عادی</option>
                        <option value="ADMIN">ادمین</option>

                       </select>
                       
                       </div>
                       <div class="form-group text-center">
                       
                       <input type="submit" name="add-user" value="افزودن کاربر" class='btn btn-success'>
                       
                       </div>
                       
                       
                       </form>
                       </div>


                    
                    
  