<?php

#in safhe baraye update kardane category ha estefade mishe








                        # in khate code baraye up date kardane data haye categoriese

                        #az url meqdare set shude update ro darone moteqayer assign mikonim ta azash dar query ha estefade konim
                                  if(isset($_GET['update'])){
                                    if(isset($_SESSION['role'])){
                                      if($_SESSION['role']==="ADMIN"){


                             $update=$_GET['update'];

                             #query k baraye farakhani meqdare darkhasti baraye update az database az an estefade mishavad
                            $queryforUpdate="SELECT * From categories Where cat_id=$update";
                            #functione mysqli k baraye ejraye query daroone database az an estefade mishavad
                            $query_for_fetch_data_from_database=mysqli_query($connection,$queryforUpdate);
                            #halqe baraye farakhani khat haye fetch shude az data base
                            while ($row=mysqli_fetch_assoc($query_for_fetch_data_from_database)) {
                                #meqdare onvane category ra daroone ye zarf rikhte ta az an baraye namayeshe meqdare feli category darone forme edit az an estefade konim
                                $update_title=$row['cat_title'];











                                #raveshe dovom baraye farkhani category k mikhahim updatesh konim va fetch kardane on az database
                                #      $stmt_for_Update_categories=mysqli_prepare($connection,"SELECT cat_title From categories Where cat_id= ?");
                                #       mysqli_stmt_bind_param($stmt_for_Update_categories,"i",$update);
                                #      mysqli_stmt_execute($stmt_for_Update_categories);
                                #      mysqli_stmt_bind_result($stmt_for_Update_categories,$update_title);
                                #      mysqli_stmt_fetch($stmt_for_Update_categories);







                                ?>



                            <form action="" method="post">
                            <div class="form-group">
                            <label for="update_cat_title">Update Category</label>
                            <input type="text" name="update_cat_title" class="form-control" value="<?php if(isset($_GET['update'])){echo $update_title;} ?>">
             
                            </div>
                            <div class="form-group text-center">
                            <input type="submit" value="Edit Category" name="change_category" class="btn btn-primary">
                           
                            </div>
                            
                            </form>






<?php
                            }
                          }
                        }
                      }

                          ?>
                      
                           
                            
                           <?php 


                            #this peace of code is for update name of category and its awsomeee

                           if(isset($_POST["change_category"])){
                         $new_name=$_POST["update_cat_title"];
                           $change_id=$update;
                            $query_change="UPDATE categories SET cat_title= '{$new_name}' WHERE cat_id= {$change_id}";
                            $result_update=mysqli_query($connection,$query_change);
                            
                            if($result_update){

                                echo "<h4 class='alert alert-succes'>با موفقیت به روز رسانی شد    </h4>";
                            }else{
                                die(mysqli_error($connection));
                            }


                           }
                           
                           
                           ?>
