

                    <?php 
                    if(isset($_GET['edit_user'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){


                        $the_edit_user_id=$_GET['edit_user'];
                        $query_for_Fetch_specific_user="SELECT * from users where user_id=$the_edit_user_id";
                        $result_query_edit_user=mysqli_query($connection,$query_for_Fetch_specific_user);
                        confirmQuery($result_query_edit_user);
                        while ($row=mysqli_fetch_assoc($result_query_edit_user)) {
                            $user_name=$row['user_name'];
                            $user_firstname=$row['user_firstname'];
                            $user_email=$row['user_email'];
                            $user_password=$row['user_password'];
                            $user_role=$row['user_role'];
                            
                        }

                    }
                    }


                    }











                    if(isset($_POST['update-user'])){

                        $up_name=trim($_POST['user_name']);
                        $up_firstname=trim($_POST['user_firstname']);
                        $up_email=trim($_POST['user_email']);
                        $up_password=trim($_POST['user_password']);
                        $up_role=trim($_POST['user_role']);
                        $up_register_date= date('y-m-d');
                 
                                  #in code baraye farakhani methode ramznegari password ha az database estefade mishe ke estelahan behesh migan salt methode crypt ham SHA-512
                       #passworde vorodi karbar ro ba kilid haye ramz negari khudemon ramznegarish kardm ta jelogiri konim az hack shudan
                   // $query_for_fetch_salt_From_database="Select randSalt from users";
                  //  $result_fetch_randsalt=mysqli_query($connection,$query_for_fetch_salt_From_database);
                 //   while($row=mysqli_fetch_assoc($result_fetch_randsalt)){
                  //      $salt=$row['randSalt'];
                //    }
                //    $up_password=crypt($up_password,$salt);



                //encrypt with this method

                $up_password= password_hash($up_password,PASSWORD_BCRYPT,array('cost'=>12));

 



                        $query="UPDATE users SET user_name='{$up_name}',user_password='{$up_password}',user_firstname='{$up_firstname}',user_email='{$up_email}',user_role='{$up_role}'";
                        $query.=" WHERE user_id={$the_edit_user_id}";
                        $update_user_result=mysqli_query($connection,$query);
                        confirmQuery($update_user_result);
                        header("Location:users.php");
                     



                    }
                    
                    
                    
                    ?>





            
                       <div class="form-group text-right">
                       <form  action="" method="post" >
                       <div class="form-group text-center">
                       <label for="user_name" dir="rtl">نام کاربری</label>
                       <input type="text" name="user_name" class='form-control text-right' value="<?php echo $user_name; ?>">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_firstname" dir="rtl">نام و نام خانوادگی کاربر</label>
                       <input type="text" name="user_firstname" class='form-control text-right' value="<?php echo $user_firstname; ?>">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_email" dir="rtl">ایمیل کاربر</label>
                       <input type="email" name="user_email" class='form-control text-right' value="<?php echo $user_email; ?>">
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="user_password" dir="rtl">رمز عبور</label>
                        <input type="password" name="user_password" class="form-control" value="<?php echo $user_password; ?>">
                       
                       </div>
                   
               
                       
               
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_role" dir="rtl"> نقش کاربر</label>
                       <select  name="user_role" class='form-control text-right' >
                        <?php 
                        if($user_role=="ADMIN"){
                            echo "<option value='ADMIN'>ادمین</option>";
                            echo "<option value='Subscriber'> کاربر عادی</option>";
                        
                        }else{
                            echo "<option value='Subscriber'> کاربر عادی</option>";
                            echo "<option value='ADMIN'>ادمین</option>";
                           
                            
                        }
                        ?>



               

                       </select>
                       
                       </div>
                       <div class="form-group text-center">
                       
                       <input type="submit" name="update-user" value="به روز رسانی کاربر" class='btn btn-success'>
                       
                       </div>
                       
                       
                       </form>
                       </div>


                    
                    
  