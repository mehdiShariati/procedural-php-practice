<table class="table table-bordered table-hover" style="width=100%">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Author</th>
                            <th>Content</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>in Response To</th>
                            <th>date</th>
                            <th>Approve</th>
                            <th>Unapprove</th>
                            <th colspan=2>Operation</th>
                        </tr>
                        
                        </thead>
                     <tbody>
                     <?php
                   
                     call_all_comments();
                     ?>
                     
                     </tbody>
                        
                        
                        
                        </table>
                    