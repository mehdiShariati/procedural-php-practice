<?php 
                            if(isset($_POST['action'])){
                                $action_method=$_POST['selectMethod'];
                              foreach ($_POST['allSelectedIds'] as $post_actions_id){
                                switch ($action_method) {
                                    case 'Publish':
                                        $query="UPDATE posts Set post_status='Publish' Where post_id='{$post_actions_id}'";
                                        $result_query=mysqli_query($connection,$query);
                                        confirmQuery($result_query);
                                        echo "<h4 class='alert alert-success'>Publish Done</h4>";
                                        break;
                                     case 'draft':
                                     $query_draft_post="UPDATE posts set post_status='draft' where post_id='{$post_actions_id}'";
                                     $result_query_post_draft=mysqli_query($connection,$query_draft_post);
                                     confirmQuery($result_query_post_draft);
                                     echo "<h4 class='alert alert-success'>Draft Done</h4>";
                                     break;

                                     case 'Delete':
                                    $query_delete_post="DELETE from posts where post_id='{$post_actions_id}'";
                                    $result_query_delete=mysqli_query($connection,$query_delete_post);
                                    confirmQuery($result_query_delete);
                                    echo "<h4 class='alert alert-danger'>Deleted Posts</h4>";


                                     break;
                                     case "clone":
                                    $query_for_Copy_post="SELECT * from posts where post_id='{$post_actions_id}'";
                                    $result_copy_query=mysqli_query($connection,$query_for_Copy_post);
                                    confirmQuery($result_copy_query);
                                    while ($row=mysqli_fetch_assoc($result_copy_query)) {
                                       
                                        $post_category_id=$row['post_category_id'];
                                        $post_title=$row['post_title'];
                                        $post_author=$row['post_author'];
                                        $post_date=$row["post_date"];
                                        $post_image=$row['post_image'];
                                        $post_content=$row['post_content'];
                                        $post_tags=$row['post_tags'];
                                        $post_comment_count=$row['post_comment_count'];
                                        $post_status=$row['post_status'];
                                        $post_views_count=$row['post_views_count'];
                                
                                       }
                                       $query="INSERT INTO posts (post_title,post_category_id,post_author,post_date,post_image,post_content,post_tags,post_comment_count,post_status,post_views_count) ";
                                       $query.="VALUES ('{$post_title}','{$post_category_id}','{$post_author}','{$post_date}','{$post_image}','{$post_content}','{$post_tags}','{$post_comment_count}','{$post_status}','{$post_views_count}')";
                                       $Insert_post_result=mysqli_query($connection,$query);
                                       confirmQuery($Insert_post_result);
                                       echo "<h4 class='alert alert-danger'>Post Copied</h4>";
                             

                                     break;
                                       case "reset_view":
                                      $query_reset="UPDATE posts SET post_views_count = 0 where post_id='{$post_actions_id}'";
                                      $query_for_reset_view=mysqli_query($connection,$query_reset);
                                       confirmQuery($query_for_reset_view);
                                      
                                       echo "<h4 class='alert alert-danger'>Reset Views Done</h4>";





                                    break;
                                    default:
                                        # code...
                                        break;
                                }




                              }








                            }




                           ?>
                           
                           
                           
                           
                           
                            <form action="" method="post">

                           <div class="row">
                           <div class="col-md-3">
                           <select class='form-control' name="selectMethod" id="">
                            <option value="Publish">Publish</option>
                            <option value="draft">draft</option>
                            <option value="Delete">Delete</option>
                            <option value="clone">Clone</option>
                            <option value="reset_view">Reset Views</option>
                           
                           </select>
                           </div>
                           <div class="col-md-3">
                           <input type="submit" name="action" class='btn btn-primary' value="Action">
                           <a href='posts.php?posts=add_post' class='btn btn-primary'>Add new</a>
                           </div>
                           </div>
                           

<table class="table table-bordered table-hover" style="width=100%">
                        <thead>
                        <tr>
                            <!--baraye check boxe sar sootoon to file myjs.js ye codi neveshte shude k btuni bahash hameye checkbox haro entekhab koni -->
                            <th><input type="checkbox" id="allSelectedIds"></th>
                            <th>ID</th>
                            <th>cat_id</th>
                            <th>title</th>
                            <th>author</th>
                            <th>date</th>
                            <th>image</th>
                            <th>content</th>
                            <th>tags</th>
                            <th>cm_count</th>
                            <th>status</th>
                            <th>views</th>
                            <th colspan=3>Operation</th>
                        </tr>
                        
                        </thead>
                     <tbody>
                     <?php
                     call_all_posts();
                     ?>
                     
                     </tbody>
                        
                        
                        
                        </table>
                    </form>