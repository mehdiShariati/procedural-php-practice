<table class="table table-bordered table-hover" style="width=100%">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>UserName</th>
                            <th>FirstName</th>
                            <th>Image</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Register Date</th>
                            <th colspan=4 class="text-center">Operation</th>
                     
                        </tr>
                        
                        </thead>
                     <tbody>
                     <?php
                     call_all_users();
                     ?>
                     
                     </tbody>
                        
                        
                        
                        </table>
                    