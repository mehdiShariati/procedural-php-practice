

                    <?php 
                    if(isset($_POST['add-post'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){

                        $title=$_POST['title'];
                        $author=$_SESSION['username'];
                        $tags=$_POST['tags'];
                        $content=$_POST['content'];
                        $categoryID=$_POST['categoryID'];
                        $status=$_POST['status'];
                        $date= date('y-m-d');
                        $comment_count=0;
                        $vies_count=0;
                            #baraye daryafte name aksi k tavase karbar upload shude az $_FILES estefade mikonim va mesle yek araye 2 bodi dakhele
                            #brackete aval name inputi ro k baraye aks moarfi kardim mizarim va toye brackete 2vom vazhe name ro mizarim b in 
                            #mani k esme file ro mikhaym
                        $image_name=$_FILES['postimg']['name'];
                           #bad az in k ye form ba enctype multipart submit mishe file ersali ro to ye makani  b esme temp negah midare k ba dastoore zir
                            #k az tabe $_FILES estefade kardim on makan ro assign mikonim b ye moteqayer ta azash estefade konim
                        $temp_image_location=$_FILES['postimg']['tmp_name'];

                        #tabe zir hamontor k az esmesh peydast abraye jabejaye file az makane temp b jayi k khudemon mikhaym estefade mishe
                        move_uploaded_file($temp_image_location,"images/$image_name");

                        $query="INSERT INTO posts (post_title,post_category_id,post_author,post_date,post_image,post_content,post_tags,post_comment_count,post_status,post_views_count) ";
                        $query.="VALUES ('{$title}','{$categoryID}','{$author}','{$date}','{$image_name}','{$content}','{$tags}','{$comment_count}','{$status}','{$vies_count}')";
                        $Insert_post_result=mysqli_query($connection,$query);
                        confirmQuery($Insert_post_result);
                        $last_inserted_id=mysqli_insert_id($connection);


                        echo "<a class='alert alert-success' href='../post.php?p_id={$last_inserted_id}'>Post Created.View This Post in Post Page</a>";
                     



                    }
                }
            }
                    
                    
                    
                    ?>





            
                       <div class="form-group text-right">
                       <form  action="" method="post" enctype="multipart/form-data">
                       <div class="form-group text-center">
                       <label for="title" dir="rtl">عنوان</label>
                       <input type="text" name="title" class='form-control text-right' placeholder="لطفا عنوان پست را اینجا بنوسید">
                       
                       </div>
                     
                       <div class="form-group text-center">
                       <label for="tags" dir="rtl">برچسب ها و یا کلمات کلیدی</label>
                       <input type="text" name="tags" class='form-control text-right' placeholder="لطفا کلمات کلیدی پست را اینجا بنوسید">
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="content" dir="rtl">محتوا ی پست</label>
                       <textarea  name="content" class='form-control text-right' id="editor" cols='30' rows='20'></textarea>
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="postimg" dir="rtl">عکس پست</label>
                       <input type="file" name="postimg" class='form-control text-right' >
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="categoryID" dir="rtl">شناسه ی دسته بندی</label>
                       <select name="categoryID" class="form-control text-center" >
                       <?php
                       
                       #query baraye fetch kardane tamame soton haye jadvale category to safhe update post
                        $query="SELECT * FROM categories";
                         $result_query_cat=mysqli_query($connection,$query);
                          # in khate code baraye namayesh dadeha az data base estefade mishe va ba in halqe ba api mysqli be rahati namayesh midim dadeha ro

                          while($row=mysqli_fetch_assoc($result_query_cat)){
                              $title= $row["cat_title"];
                              $Id= $row["cat_id"];
                       
                                echo "<option value='{$Id}'>{$title}</option>";
                          }
                       ?>
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       </select>
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="status" dir="rtl">وضعیت پست</label>
                       <select  name="status" class='form-control text-right'>
                        <option value="Publish">منتشر شود</option>
                        <option value="draft">به پیش نویس ها افزوده شود</option>

                       </select>
                       
                       </div>
                       <div class="form-group text-center">
                       
                       <input type="submit" name="add-post" value="افزودن پست" class='btn btn-success'>
                       
                       </div>
                       
                       
                       </form>
                       </div>


                    
                    
  