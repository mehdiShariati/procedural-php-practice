                        
                        
                        <?php

                        if(isset($_GET['update'])){
                            if(isset($_SESSION['role'])){
                                if($_SESSION['role']==="ADMIN"){
                            
                            $update=$_GET['update'];
                            
                            $query="SELECT * FROM posts WHERE post_id = $update";
                            $result_query=mysqli_query($connection,$query);
                            confirmQuery($result_query);
                            while ($row=mysqli_fetch_assoc($result_query)) {
                                $post_id=$row['post_id'];
                                $post_category_id=$row['post_category_id'];
                                $post_title=$row['post_title'];
                                $post_author=$row['post_author'];
                                $post_date=$row["post_date"];
                                $post_image=$row['post_image'];
                                $post_content=$row['post_content'];
                                $post_tags=$row['post_tags'];
                                $post_comment_count=$row['post_comment_count'];
                                $post_status=$row['post_status'];
                                $post_views_count=$row['post_views_count'];
                        
                               }

                               }
                            }
                        }
                        
                        
                        ?>
                        <?php
                        if(isset($_POST['update_post'])){
                            $upTitle=$_POST['title'];
                     
                            $upTags=$_POST['tags'];
                            $upContent=$_POST['content'];
                            #baraye daryafte name aksi k tavase karbar upload shude az $_FILES estefade mikonim va mesle yek araye 2 bodi dakhele
                            #brackete aval name inputi ro k baraye aks moarfi kardim mizarim va toye brackete 2vom vazhe name ro mizarim b in 
                            #mani k esme file ro mikhaym
                            $upimgNAME=$_FILES['postimg']['name'];
                            #bad az in k ye form ba enctype multipart submit mishe file ersali ro to ye makani  b esme temp negah midare k ba dastoore zir
                            #k az tabe $_FILES estefade kardim on makan ro assign mikonim b ye moteqayer ta azash estefade konim
                            $temp_place_for_save_pic=$_FILES['postimg']['tmp_name'];
                            $upCatId=$_POST['categoryID'];
                            $upPostStatus=$_POST['status'];
                            $upPostId=$_POST['post_id'];
                            #tabe zir hamontor k az esmesh peydast abraye jabejaye file az makane temp b jayi k khudemon mikhaym estefade mishe
                            move_uploaded_file($temp_place_for_save_pic,"images/$upimgNAME");
                            #in khate code ro baraye in neveshtam k age to edite ye post aksi ro update nakardim hamon aks qablie bmone rosh
                            #khate paeen mige k age forme image khalo bud bia akse qablie khude post ro jaygozinesh kon
                            if(empty($upimgNAME)){   
                                $query="SELECT * FROM posts Where post_id=$update";
                                $query_for_empty_image_field=mysqli_query($connection,$query);
                                confirmQuery($query_for_empty_image_field);
                                while($row=mysqli_fetch_assoc($query_for_empty_image_field)){
                                $upimgNAME=$row['post_image'];
                                }



                            }




                            $query_for_update_post="UPDATE posts SET post_title='{$upTitle}',post_Category_id='{$upCatId}',post_image='{$upimgNAME}',post_content='{$upContent}',post_tags='{$upTags}',post_status='{$upPostStatus}' WHERE post_id = '{$upPostId}'";
                            $result_update_query=mysqli_query($connection,$query_for_update_post);
                            echo "<a class='alert alert-success' href='../post.php?p_id={$upPostId}'>View This Post</a>";
                           



                        }
                        
                        
                        
                        
                        ?>
                        <div class="form-group text-right">
                       <form  action="" method="post" enctype="multipart/form-data">
                       <div class="form-group text-center">
                       <label for="title" dir="rtl">عنوان</label>
                       <input type="text" value="<?php echo $post_title; ?>" name="title" class='form-control text-right' placeholder="لطفا عنوان پست را اینجا بنوسید">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="author" dir="rtl">نویسنده</label>
                       <input type="text" name="author" value="<?php echo $post_author; ?>" class='form-control text-right' disabled>
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="tags" dir="rtl">برچسب ها و یا کلمات کلیدی</label>
                       <input type="text" name="tags" value="<?php echo $post_tags; ?>" class='form-control text-right' placeholder="لطفا کلمات کلیدی پست را اینجا بنوسید">
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="content" dir="rtl">محتوا ی پست</label>
                       <textarea  name="content"  class='form-control text-right' id="editor" cols='30' rows='10'><?php echo $post_content; ?></textarea>
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="postimg" dir="rtl">عکس پست</label>
                       <img src='images/<?php echo $post_image; ?>' width="100" class="img-responsive">
                       <input type="file" name="postimg" class='form-control text-right' >
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="categoryID" dir="rtl">شناسه ی دسته بندی</label>
                       
                       <select name="categoryID"  class="form-control text-center" >
                       <?php
                       
                       #query baraye fetch kardane tamame soton haye jadvale category to safhe update post
                        $query="SELECT * FROM categories";
                         $result_query_cat=mysqli_query($connection,$query);
                          # in khate code baraye namayesh dadeha az data base estefade mishe va ba in halqe ba api mysqli be rahati namayesh midim dadeha ro

                          while($row=mysqli_fetch_assoc($result_query_cat)){
                              $title= $row["cat_title"];
                              $Id= $row["cat_id"];
                       
                                echo "<option value='{$Id}'>{$title}</option>";
                          }
                       ?>
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       
                       </select>
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="status" dir="rtl">وضعیت پست</label>
                       <select  name="status" class='form-control text-right'>
                       <?php if($post_status=='Publish'){
                           echo "<option value='Publish'>منتشر شود</option>";
                           echo "<option value='draft'>به پیش نویس ها افزوده شود</option>";


                       }else{
                        echo "<option value='draft'>به پیش نویس ها افزوده شود</option>";
                        echo "<option value='Publish'>منتشر شود</option>";
                       } ?>
                        
                       

                       </select>
                       <input type="hidden" name="post_id" value="<?php echo $post_id ?>">
                       </div>
                       <div class="form-group text-center">
                       
                       <input type="submit" name="update_post" value="به روز رسانی پست" class='btn btn-primary'>
                       
                       </div>
                       
                       
                       </form>
                       </div>

