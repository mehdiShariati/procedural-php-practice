<?php
    include "includes/header.php";
    #include Header
    ?>

    <div id="wrapper">

        <!-- Navigation -->
      <?php
       include "includes/navigation.php"; 
        ?>



        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                          Welcome Back 
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>

                    <?php 
                    if(isset($_SESSION['username'])){
                        $the_edit_profile_user_name=$_SESSION['username'];
                    $query_for_Fetch_specific_user_profile="SELECT * from users where user_name='{$the_edit_profile_user_name}'";
                        $result_query_for_Fetch_specific_user_profile=mysqli_query($connection,$query_for_Fetch_specific_user_profile);
                        confirmQuery($result_query_for_Fetch_specific_user_profile);
                        while ($row=mysqli_fetch_assoc($result_query_for_Fetch_specific_user_profile)) {
                            
                            $user_firstname=$row['user_firstname'];
                            $user_email=$row['user_email'];
                            $user_password=$row['user_password'];
                 
                            
                        }



                    }











                    if(isset($_POST['update-profile'])){

                       
                        $up_firstname=$_POST['user_firstname'];
                        $up_email=$_POST['user_email'];
                        $up_password=$_POST['user_password'];
                        $up_profile_image_name=$_FILES['user_image']['name'];
                        $temp_place_of_uploaded_image=$_FILES['user_image']['tmp_name'];
                      
                      
                        move_uploaded_file($temp_place_of_uploaded_image,"images/$up_profile_image_name");;


                        $query="UPDATE users SET user_image='{$up_profile_image_name}',user_password='{$up_password}',user_firstname='{$up_firstname}',user_email='{$up_email}'";
                        $query.=" WHERE user_name='{$the_edit_profile_user_name}'";
                        $update_user_result=mysqli_query($connection,$query);
                        confirmQuery($update_user_result);
                        header("Location:users.php");
                     



                    }
                    
                    
                    
                    ?>





            
                       <div class="form-group text-right">
                       <form  action="" method="post" enctype="multipart/form-data">
                    
                       <div class="form-group text-center">
                       <label for="user_firstname" dir="rtl">نام و نام خانوادگی کاربر</label>
                       <input type="text" name="user_firstname" class='form-control text-right' value="<?php echo $user_firstname; ?>">
                       
                       </div>
                       <div class="form-group text-center">
                       <label for="user_email" dir="rtl">ایمیل کاربر</label>
                       <input type="email" name="user_email" class='form-control text-right' value="<?php echo $user_email; ?>">
                       
                       </div>
                       
                       <div class="form-group text-center">
                       <label for="user_password" dir="rtl">رمز عبور</label>
                        <input type="password" name="user_password" class="form-control" value="<?php echo $user_password; ?>">
                       
                       </div>
                   
                       <div class="form-group text-center">
                       <label for="user_image" dir="rtl">آواتار </label>
                        <input type="file" name="user_image" class="form-control">
                       
                       </div>
                       
               
                       
               
                      

               

              
                       
                       </div>
                       <div class="form-group text-center">
                       
                       <input type="submit" name="update-profile" value="به روز رسانی کاربر" class='btn btn-success'>
                       
                       </div>
                       
                       
                       </form>
                       </div>


                    
                    
                       </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

  <?php include "includes/footer.php"; ?>