<?php
    include "includes/header.php";
    include "includes/navigation.php"; 
    #include Header

    ?>

    <div id="wrapper">

        <!-- Navigation -->
   


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                          Welcome Back 
                            <small>Author</small>
                            <?php echo date('Y-M-d h:i:s a'); ?>
                        </h1>
                <?php
                       if(isset($_GET['user'])){
                           $user_status=$_GET['user'];

                       }else{
                           $user_status="";
                       }
                       switch($user_status){
                        case 'view_all_users':
                        include "includes/view_all_users.php";
                         break;
                         case 'add_user':
                         include "includes/add_user.php";
                             break;
                             case 'update':
                             include "includes/update_user.php";
                                 break;
                     default:
                     include "includes/view_all_users.php";
                         break;




                    }
                    if(isset($_GET['delete'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $del_id=$_GET['delete'];
                        $query="DELETE from users where user_id='{$del_id}'";
                        $result_del_users=mysqli_query($connection,$query);
                        confirmQuery($result_del_users);
                        header("location:users.php");

                            }
                        }

                    }
                    if(isset($_GET['chngtoadmin'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $user_id_admin=$_GET['chngtoadmin'];
                    $query_for_change_to_admin="UPDATE users SET user_role='ADMIN' where user_id={$user_id_admin}";
                    $result_query_change_to_admin=mysqli_query($connection,$query_for_change_to_admin);
                    confirmQuery($result_query_change_to_admin);
                    header("location:users.php");

                            }
                        }


                    }
                    if(isset($_GET['chngtosub'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $user_id_sub=$_GET['chngtosub'];
                        $query_for_change_to_sub="UPDATE users SET user_role='Subscriber' where user_id={$user_id_sub}";;
                    $result_query_change_to_sub=mysqli_query($connection,$query_for_change_to_sub);
                    confirmQuery($result_query_change_to_sub);
                    header("location:users.php");
                            }
                        }



                    }

                            ?>

           
                    
                    

                    </div>
                 
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

  <?php include "includes/footer.php"; ?>