<?php
    include "includes/header.php";
    include "includes/navigation.php"; 
    #include Header

    ?>

    <div id="wrapper">

        <!-- Navigation -->
   


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                          Welcome Back 
                            <small>Author</small>
                            <?php echo date('Y-M-d h:i:s a'); ?>
                        </h1>
                        
                <?php
                       if(isset($_GET['posts'])){
                           $posts=$_GET['posts'];

                       }else{
                           $posts="";
                       }
                       switch($posts){
                        case 'view_all_posts':
                        include "includes/view_all_posts.php";
                         break;
                         case 'add_post':
                         include "includes/add_post.php";
                             break;
                             case 'update':
                             include "includes/update-post.php";
                                 break;
                     default:
                     include "includes/view_all_posts.php";
                         break;




                    }
                    if(isset($_GET['delete'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']==="ADMIN"){
                        $del_id=$_GET['delete'];
                        $query="DELETE from posts where post_id='{$del_id}'";
                        $result_del_post=mysqli_query($connection,$query);
                        confirmQuery($result_del_post);
                        header("Location:posts.php");
                            }
                        }


                    }

                            ?>

           
                    
                    

                    </div>
                 
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

  <?php include "includes/footer.php"; ?>