<?php
    include "includes/header.php";
    include "includes/navigation.php"; 
    #include Header

    ?>

    <div id="wrapper">

        <!-- Navigation -->
   


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                          Welcome Back 
                            <small>Author</small>
                            <?php echo date('Y-M-d h:i:s a'); ?>
                        </h1>
                <?php
                       if(isset($_GET['cm'])){
                           $cm_status=$_GET['cm'];

                       }else{
                           $cm_status="";
                       }
                       switch($cm_status){
                        case 'view_all_comments':
                        include "includes/view_all_posts.php";
                         break;
                         case 'add_post':
                         include "includes/add_post.php";
                             break;
                             case 'update':
                             include "includes/update-post.php";
                                 break;
                     default:
                     include "includes/view_all_comments.php";
                         break;




                    }
                    if(isset($_GET['delete'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']=="ADMIN"){
                        $del_id=$_GET['delete'];
                        $query="DELETE from comments where comment_id='{$del_id}'";
                        $result_del_comments=mysqli_query($connection,$query);
                        confirmQuery($result_del_comments);
                        header("location:comments.php");

                            }
                        }

                    }
                    if(isset($_GET['approveokID'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']=="ADMIN"){
                        $approveOkId=$_GET['approveokID'];
                    $query_for_approve_cms="UPDATE comments SET comment_status='APPROVE' where comment_id={$approveOkId}";
                    $result_query_approve=mysqli_query($connection,$query_for_approve_cms);
                    confirmQuery($result_query_approve);
                    header("location:comments.php");

                            }
                        }


                    }
                    if(isset($_GET['approveNokkID'])){
                        if(isset($_SESSION['role'])){
                            if($_SESSION['role']=="ADMIN"){
                        $unApproveId=$_GET['approveNokkID'];
                    $query_for_unapprove_a_comment="UPDATE comments Set comment_status='UNAPPROVE' where comment_id={$unApproveId}";
                    $result_query_unapprove_a_cm=mysqli_query($connection,$query_for_unapprove_a_comment);
                    confirmQuery($result_query_unapprove_a_cm);
                    header("location:comments.php");
                            }
                        }



                    }

                            ?>

           
                    
                    

                    </div>
                 
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

  <?php include "includes/footer.php"; ?>