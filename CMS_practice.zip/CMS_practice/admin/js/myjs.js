$(document).ready(function(){
    // Enable pusher logging - don't include this in production












    //code zir baraye ckeditor ast k be onvane virayeshgare matn az an estefade mishavad
    ClassicEditor
    .create( document.querySelector( '#editor' ) )
    .catch( error => {
        console.error( error );
    } );
    //code zir baraye in neveshte shude k agar sar sotoone check box haye post ra click koni hamash entekhab bshe 
    $('#allSelectedIds').click(function(e){
        //mige agar tik khurde bud sar sootoon invaqt code paeeno ejra kon else ya hamon dar qeyre in sorat code paeeni
        if(this.checked){
            // in dastoor mige k hameye checkbox haye k class checkBoxes daran ro tik bzan
        $('.checkBoxes').each(function(){
            this.checked=true;

        });


        }else{
             // in dastoor mige k hameye checkbox haye k class checkBoxes daran ro tikesho  bardar
            $('.checkBoxes').each(function(){
                this.checked=false;
            });

             
        }





    });
    //this is for loader ADmin Side k yek div sakhtim ba ye dive dg dakhelesh va aks ha ro be onvane background image toye css behesh dadim
    var loader_box="<div id='load-screen'><div id='loading'></div></div>";
    $("body").prepend(loader_box);
    $('#load-screen').delay(200).fadeOut(600,function(){
     $(this).remove();
    });







});


//code zir baraye farakhani teadde karbar haye online ba ajaxe k ma darkhast ro mostaqiman be file functions.php dakhele folder iincludes ersal mikonim 
function ajx_loaduserOnline_withoutRefresh(){
$.get("includes/functions.php?onlineuser=result",function(data){
    //elementi k klase qtfy dare be onvane makane namayesh dahandeye on meqdari k farakhani kardim be kar mire
    $(".qtfy").text(data)
});






}
// ba code zir ham ye timer gozashtim k har ye modat ye bar on qesmate user haye online refresh bshe 
setInterval(function(){
    ajx_loaduserOnline_withoutRefresh();
},1000);
