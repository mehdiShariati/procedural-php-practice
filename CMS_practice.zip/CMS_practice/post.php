<?php
#adding Header
include("includes\header.php");

?>
    <!-- Page Content -->
    <div class="container">

         <div class="row">
            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>
                <!--  this peace of code is for fetch posts from data base to our index pae so its neccesery
                in khate codahaye paeeno ba estefade az api mysqli az data base fetch kardam va paeen namayesh dadam   -->
                <!--  Blog Post -->
                <?php 
                    if (isset($_GET['p_id'])) {

                        $urlId=$_GET['p_id'];
                        

                    $query_for_increase_post_view_count="UPDATE posts SET post_views_count=post_views_count +1 where post_id='{$urlId}'";
                    $result_increase_view=mysqli_query($connection,$query_for_increase_post_view_count);

                    if(!$result_increase_view){
                        die(mysqli_error($connection));
                    }













                   

                    #query bara farakhani post ha 
                    $query="SELECT * FROM posts where post_id={$urlId}";
                    #functione query baraye ejraye query neveshte shude be samte data base
                    $result_post_fetch=mysqli_query($connection,$query);
                    #halqe baraye farakhani khat b khate data haye fetch shude az database
                   while($row=mysqli_fetch_assoc($result_post_fetch)){
                       #tak take soton haye database ro rikhtam toye motaqeyer ha ta betunam in ja farakhanish konam
                 $post_title=$row['post_title'];
                    $post_content=$row['post_content'];
                    $post_date=$row["post_date"];
                    $post_author=$row["post_author"];
                    $post_image=$row['post_image'];
                    $post_id=$row['post_id'];

                    #code hayee paeen hamashun html an va done done moteqayer haro toye harbar iteration mirizam dakheleshun va be tedad khat haye fetch shdue az data base ejra mishan
                    ?>
                    <h2> <a href='post/<?php echo $post_id; ?>'><?php echo $post_title; ?></a></h2>
                   <p class='lead'>by  <a href='author.php?author=<?php echo $post_author; ?>'><?php echo $post_author; ?></a></p>
                   <p><span class='glyphicon glyphicon-time'></span> Posted on <?php echo $post_date; ?></p><hr>
                   <img class='img-responsive' src='/cms_practice/admin/images/<?php echo $post_image; ?>' alt='<?php echo $post_image; ?>'><hr>
                    <p><?php echo $post_content; ?></p>
                   



                    <?php
                   }
                }
                
                ?>
               
               
        
                
                
               
              


                



                <hr>


                <!-- Blog Comments -->
                   <?php 
                   # baraye ezafe kardane ye comment k az form ba methode post estefade shude va b sorate unapprove dar db zakhire mishe ta zamani
                   #kapprove nashe be karbar zire in safhe namayesh dade nmishe
                      if(isset($_POST['create-comment'])){
                          
                        $cm_author=$_POST['comment_author'];
                        $cm_email=$_POST['comment_email'];
                        $cm_content=$_POST["comment_content"];
                        if(!empty($cm_author) && !empty($cm_email) && !empty($cm_content)){ 


                        $cm_date=date('y-m-d');
                        #id post ro az url migirm chun ba url omadim b in safhe
                        $cm_post_id=$post_id;
                        $cm_status="UNAPPROVE";
                        $query_for_insert_comment="INSERT INTO comments (comment_post_id,comment_author,comment_email,comment_content,comment_status,comment_date) VALUES ";
                        $query_for_insert_comment.="('{$cm_post_id}','{$cm_author}','{$cm_email}','{$cm_content}','{$cm_status}','{$cm_date}')";
                        $result_insert_comment=mysqli_query($connection,$query_for_insert_comment);
                        if($result_insert_comment){
                            echo "Your comment is Sending and will Approve soon";
                        }else{
                            die(mysqli_error($connection));
                        }
                      //  $comment_count_increase_in_post_table="UPDATE posts SET post_comment_count=post_comment_count+1 where post_id={$post_id}";
                      //  $result_increse_cm_count=mysqli_query($connection,$comment_count_increase_in_post_table);
                      //  if($result_increse_cm_count){
                         
//                      //}
                    }else{

                        echo "<script>alert('Comment Fields is Empty') </script>";

                    }

                      }
                   ?>





                <!-- Comments Form -->
                <div class="well">
                    <h4>Leave a Comment:</h4>
                    <form role="form" action="" method="post">
                    <div class="form-group">
                            <label for="comment_author">Your Name:</label>
                            <input class="form-control" name="comment_author" type="text">
                        </div>
                        <div class="form-group">
                            <label for="comment_email">Your Email:</label>
                            <input class="form-control" name="comment_email" type="email">
                        </div>
                        <div class="form-group">
                             <label for="comment_content">Comment:</label>
                            <textarea name="comment_content" class="form-control" rows="3"></textarea>
                        </div>
                        <button type="submit" name="create-comment" class="btn btn-primary">Post Comment</button>
                    </form>
                </div>
                
                <hr>

                <!-- Posted Comments -->
                <?php
                #commnt hayi b karbar namayesh dade mishe k tavsote karbar add shude va tavasote admin approve shude
                $query_for_fetch_this_post_comments="SELECT * FROM comments WHERE comment_post_id={$urlId} and comment_status='APPROVE' ORDER BY comment_id DESC";
                        $result_query_fetch_specific_comments=mysqli_query($connection,$query_for_fetch_this_post_comments);
                        
                        while($row=mysqli_fetch_assoc($result_query_fetch_specific_comments)){
                 
                            $comment_author=$row['comment_author'];
                            $comment_email=$row['comment_email'];
                            $comment_content=$row["comment_content"];
                            $comment_status=$row['comment_status'];
                            $comment_date=$row['comment_date'];
                            //comment body
                        #    <!-- Comment -->
                        echo "<div class='media'>";
                        echo "<a class='pull-left' href='#'><img class='media-object' src='http://placehold.it/64x64' alt=''></a>";
                        echo "<div class='media-body'>";
                        echo "<h4 class='media-heading'>By:{$comment_email}</h4><br><p><span class='glyphicon glyphicon-time'></span> Posted on {$comment_date}</p>{$comment_content}</div></div><hr>";
                               
                        }
         



                           
                        ?>
                        

                <!-- Comment -->
            

             





                <!-- Pager -->
                <ul class="pager">
                    <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li>
                </ul>
              
               














  </div>
  <?php include "includes/sidebar.php";
     
     #adding sidebar ?>

                </div>
             
         </div>
           
           

   

            <hr> 
        
        
        
     <?php #adding Footer
     include("includes/footer.php");
     ?>