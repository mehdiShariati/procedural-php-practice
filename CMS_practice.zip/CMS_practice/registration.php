 <?php  include "includes/header.php";
 $dotenv=Dotenv\Dotenv::create(__DIR__);
 $dotenv->load();
 $options = array(
     'cluster' => 'ap1',
     'useTLS' => true
 );

 $pusher = new Pusher\Pusher(
     getenv('APP_KEY'),
     getenv('APP_SECRET'),
     getenv('APP_ID'),
     $options
 );
 ?>
    
    
 
    <!-- Page Content -->
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <?php 
                if(isset($_POST['submit'])){
                    $username=trim_and_Escape_String_mysqli($_POST['username']);
                    $password=trim_and_Escape_String_mysqli($_POST['password']);
                    $email=trim_and_Escape_String_mysqli($_POST['email']);
                    $user_register_date=date('y-m-d');

                    if(check_username_and_email($username,$email)) {
                   $password= password_hash($password, PASSWORD_BCRYPT, array('cost' => 12));



                        #query for insert user in database after validate with 3 top methods
                        Insert_user_query($username,$email,$password,$user_register_date);


                        $pusher->trigger('notifications','new_user',"an User has been Registered");


                            }






                }







      //              #in code baraye farakhani methode ramznegari password ha az database estefade mishe ke estelahan behesh migan salt methode crypt ham SHA-512
        //               #passworde vorodi karbar ro ba kilid haye ramz negari khudemon ramznegarish kardm ta jelogiri konim az hack shudan
        //            $query_for_fetch_salt_From_database="Select randSalt from users";
       //             $result_fetch_randsalt=mysqli_query($connection,$query_for_fetch_salt_From_database);
      //              while($row=mysqli_fetch_assoc($result_fetch_randsalt)){
      //                  $salt=$row['randSalt'];
      //              }
        //            $password=crypt($password,$salt);
//
                // yeki az jadid tarin method haye hash kardane passworde 





































                ?>
                <h1>Register</h1>

                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">
                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input type="text" name="username" id="username" class="form-control" placeholder="Enter Desired Username">
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com">
                        </div>
                         <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="password" id="key" class="form-control" placeholder="Password">
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Register">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>
